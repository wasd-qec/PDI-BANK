import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class FilterPopup extends JDialog {

    public FilterPopup(JFrame parent) {
        super(parent, true);
        setSize(450, 350);
        setUndecorated(true);
        setLayout(null);
        setLocationRelativeTo(parent);
        setBackground(new Color(0, 0, 0, 0));

        // Rounded popup
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 40, 40));

        JPanel container = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(250, 240, 220));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 40, 40);
            }
        };
        container.setBounds(0, 0, 450, 350);
        container.setOpaque(false);
        add(container);

        // Title
        JLabel title = new JLabel("Filter by", SwingConstants.CENTER);
        title.setFont(new Font("Serif", Font.BOLD, 24));
        title.setBounds(0, 15, 450, 30);
        container.add(title);

        // Account Status label
        JLabel statusLabel = new JLabel("Account Status");
        statusLabel.setFont(new Font("Serif", Font.PLAIN, 18));
        statusLabel.setBounds(150, 65, 200, 25);
        container.add(statusLabel);

        // Rounded ComboBox
        String[] statusOptions = { "Activated", "Inactivated", "Deleted" };
        RoundedComboBox<String> statusBox = new RoundedComboBox<>(statusOptions, 18);
        statusBox.setBounds(125, 90, 200, 38);
        statusBox.setBackground(new Color(225, 200, 130));
        container.add(statusBox);

        // Address label
        JLabel addressLabel = new JLabel("Address");
        addressLabel.setFont(new Font("Serif", Font.PLAIN, 18));
        addressLabel.setBounds(195, 130, 100, 25);
        container.add(addressLabel);

        // Rounded text field
        RoundedTextField addressField = new RoundedTextField(18);
        addressField.setBounds(125, 155, 200, 38);
        container.add(addressField);

        // Balance label
        JLabel balanceLabel = new JLabel("Balance");
        balanceLabel.setFont(new Font("Serif", Font.PLAIN, 18));
        balanceLabel.setBounds(195, 195, 100, 25);
        container.add(balanceLabel);

        RoundedTextField balanceField = new RoundedTextField(18);
        balanceField.setBounds(125, 220, 200, 38);
        container.add(balanceField);

        // Rounded Cancel Button
        JButton cancelBtn = new RoundedButton("Cancel", 20);
        cancelBtn.setBounds(105, 280, 100, 40);
        cancelBtn.setBackground(Color.WHITE);
        cancelBtn.setForeground(new Color(80, 80, 80));
        cancelBtn.addActionListener(e -> dispose());
        container.add(cancelBtn);

        // Rounded Filter Button
        JButton filterBtn = new RoundedButton("Filter", 20);
        filterBtn.setBounds(245, 280, 100, 40);
        filterBtn.setBackground(new Color(225, 200, 130));
        filterBtn.setForeground(new Color(40, 40, 40));
        filterBtn.addActionListener(e -> dispose());
        container.add(filterBtn);
    }

    // ---- Rounded TextField ----
    static class RoundedTextField extends JTextField {
        private int radius;

        public RoundedTextField(int radius) {
            this.radius = radius;
            setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
            setBackground(new Color(225, 200, 130));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
            super.paintComponent(g);
            g2.dispose();
        }
    }

    // ---- Rounded ComboBox ----
    static class RoundedComboBox<E> extends JComboBox<E> {
        private int radius;

        public RoundedComboBox(E[] items, int radius) {
            super(items);
            this.radius = radius;
            setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
            super.paintComponent(g);
            g2.dispose();
        }
    }

    // ---- Rounded Button ----
    static class RoundedButton extends JButton {
        private int radius;

        public RoundedButton(String text, int radius) {
            super(text);
            this.radius = radius;
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
            g2.setColor(getForeground());
            FontMetrics fm = g2.getFontMetrics();
            int x = (getWidth() - fm.stringWidth(getText())) / 2;
            int y = (getHeight() + fm.getAscent()) / 2 - 3;
            g2.drawString(getText(), x, y);
            g2.dispose();
        }
    }
}
